Template utilisé pour le projet de programmation POO L2
