package fr.pantheonsorbonne.ufr27.miashs.poo;

import java.lang.Double;
import java.lang.String;
import java.util.ArrayList;

public final class ItemAnalyzer {
  private ArrayList<Item> items = new ArrayList<>();

  public ItemAnalyzer(ArrayList<Item> items) {
    this.items=items;
  }

  public Double getMoyennePrix() {
    // code here
    return null;
  }

  public Double getCorrelationPromotion() {
    // code here
    return null;
  }

  public String getCouleurLaPlusFrequente() {
    // code here
    return null;
  }

  public Double getEcartTypePrix() {
    // code here
    return null;
  }

  public ArrayList<Integer> getEffectifDesTypes() {
    // code here
    return null;
  }
}
