package fr.pantheonsorbonne.ufr27.miashs.poo;

import java.lang.Boolean;
import java.lang.Double;
import java.lang.String;
import java.util.ArrayList;

public final class Item {
  private Double Prix;

  private String Couleur;

  private Boolean Promotion;

  private ArrayList<String> DispoProduit;

  private ArrayList<String> Type;

  public Double getPrix() {
    return this.Prix;
  }

  public void setPrix(Double Prix) {
    this.Prix=Prix;
  }

  public String getCouleur() {
    return this.Couleur;
  }

  public void setCouleur(String Couleur) {
    this.Couleur=Couleur;
  }

  public Boolean getPromotion() {
    return this.Promotion;
  }

  public void setPromotion(Boolean Promotion) {
    this.Promotion=Promotion;
  }

  public ArrayList<String> getDispoProduit() {
    return this.DispoProduit;
  }

  public void setDispoProduit(ArrayList<String> DispoProduit) {
    this.DispoProduit=DispoProduit;
  }

  public ArrayList<String> getType() {
    return this.Type;
  }

  public void setType(ArrayList<String> Type) {
    this.Type=Type;
  }
}
